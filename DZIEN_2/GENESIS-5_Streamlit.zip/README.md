# GENESIS-5

Aplikacja Streamlit prezentująca optymalizację pięciu parametrów produkcyjnych za pomocą algorytmu genetycznego.

## Uruchomienie

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux / macOS:

```bash
source .venv/bin/activate
```

Następnie:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Model procesu i ekonomii jest syntetyczny i przeznaczony do celów szkoleniowych.
