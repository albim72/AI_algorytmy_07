from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st


st.set_page_config(
    page_title="GENESIS-5 | Optymalizacja produkcji",
    page_icon="🧬",
    layout="wide",
)

st.markdown(
    """
    <style>
    .stApp {
        background:
          radial-gradient(circle at 10% 10%, rgba(16,185,129,.11), transparent 28%),
          radial-gradient(circle at 92% 8%, rgba(124,58,237,.15), transparent 30%),
          linear-gradient(180deg, #06101e 0%, #0a1324 55%, #07101d 100%);
    }
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #091426, #101a30);
        border-right: 1px solid rgba(103,232,249,.16);
    }
    .hero {
        padding: 1.4rem 1.6rem;
        border-radius: 24px;
        border: 1px solid rgba(103,232,249,.23);
        background: linear-gradient(135deg, rgba(15,118,110,.25), rgba(91,33,182,.25));
        box-shadow: 0 20px 70px rgba(0,0,0,.34);
        margin-bottom: 1rem;
    }
    .hero h1 {
        margin: 0;
        font-size: clamp(2.2rem, 5vw, 4.6rem);
        letter-spacing: -.05em;
        background: linear-gradient(90deg, #67e8f9, #a7f3d0, #c4b5fd);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .hero p {color:#cbd5e1; margin:.35rem 0 0; font-size:1.05rem}
    .card {
        padding: 1rem;
        border-radius: 18px;
        border: 1px solid rgba(148,163,184,.18);
        background: rgba(15,23,42,.68);
        min-height: 128px;
    }
    .card .label {color:#94a3b8; font-size:.76rem; text-transform:uppercase; letter-spacing:.08em}
    .card .value {color:#a7f3d0; font-size:1.75rem; font-weight:800; line-height:1.15; margin-top:.3rem}
    .card .unit {color:#cbd5e1; font-size:.9rem}
    div[data-testid="stMetric"] {
        padding:.75rem .9rem;
        border:1px solid rgba(148,163,184,.17);
        border-radius:16px;
        background:rgba(15,23,42,.72)
    }
    .stButton > button {
        min-height:3.1rem;
        border-radius:15px;
        border:1px solid rgba(103,232,249,.35);
        background:linear-gradient(90deg,#0f766e,#6d28d9);
        color:white;
        font-weight:800;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


@dataclass(frozen=True)
class Parameter:
    name: str
    short: str
    unit: str
    low: float
    high: float
    decimals: int


PARAMETERS = [
    Parameter("Temperatura strefy", "Temperatura", "°C", 160.0, 220.0, 1),
    Parameter("Ciśnienie formowania", "Ciśnienie", "bar", 4.0, 12.0, 2),
    Parameter("Prędkość linii", "Prędkość", "m/min", 25.0, 95.0, 1),
    Parameter("Czas chłodzenia", "Chłodzenie", "s", 8.0, 38.0, 1),
    Parameter("Dozowanie dodatku", "Dodatek", "%", 0.4, 4.5, 2),
]

BOUNDS = np.array([(p.low, p.high) for p in PARAMETERS], dtype=float)
RANGES = BOUNDS[:, 1] - BOUNDS[:, 0]


def evaluate(population: np.ndarray) -> dict[str, np.ndarray]:
    """Syntetyczny cyfrowy bliźniak procesu kompozytu polimerowego."""
    t, p, v, c, a = population.T

    target_t = 187.0 + 0.105 * (v - 55.0) - 1.5 * (a - 2.2)
    target_p = 8.1 + 0.022 * (v - 60.0)
    target_c = 20.5 - 0.055 * (t - 188.0) + 0.045 * (v - 60.0)

    quality = (
        99.0
        - 0.050 * (t - target_t) ** 2
        - 0.92 * (p - target_p) ** 2
        - 0.0105 * (v - 66.0) ** 2
        - 0.075 * (c - target_c) ** 2
        - 2.75 * (a - 2.25) ** 2
        + 1.10 * np.sin((t - 160.0) / 5.8) * np.cos((v - 25.0) / 9.5)
        + 0.65 * np.sin(p * 2.2 + a)
    )
    quality = np.clip(quality, 45.0, 99.8)

    defects = (
        0.55
        + 0.0028 * (t - target_t) ** 2
        + 0.095 * (p - target_p) ** 2
        + 0.0017 * np.maximum(v - 72.0, 0.0) ** 2
        + 0.018 * (c - target_c) ** 2
        + 0.42 * (a - 2.25) ** 2
    )
    defects = np.clip(defects, 0.25, 22.0)

    throughput = 9.9 * v * (1.0 - 0.0052 * (c - 8.0)) * (1.0 + 0.012 * (p - 8.0))
    throughput = np.clip(throughput, 190.0, 1050.0)

    energy = 72.0 + 0.70 * (t - 160.0) + 2.15 * (p - 4.0) + 0.11 * v + 0.26 * c + 1.4 * a
    energy = np.clip(energy, 70.0, 175.0)

    good_output = throughput * (1.0 - defects / 100.0)
    profit = (
        good_output * 3.10
        - energy * 0.92
        - throughput * (defects / 100.0) * 4.80
        - throughput * (a / 100.0) * 2.20
    )

    throughput_score = np.clip((throughput - 300.0) / 650.0 * 100.0, 0.0, 100.0)
    energy_cost = np.clip((energy - 75.0) / 95.0 * 100.0, 0.0, 100.0)
    defect_cost = np.clip(defects / 12.0 * 100.0, 0.0, 100.0)
    profit_score = np.clip((profit - 400.0) / 2200.0 * 100.0, 0.0, 100.0)

    fitness = (
        0.43 * quality
        + 0.25 * throughput_score
        + 0.13 * (100.0 - energy_cost)
        + 0.11 * (100.0 - defect_cost)
        + 0.08 * profit_score
    )

    fitness -= np.maximum(90.0 - quality, 0.0) * 2.8
    fitness -= np.maximum(defects - 4.0, 0.0) * 5.0
    fitness -= np.maximum(430.0 - good_output, 0.0) * 0.035
    fitness -= ((t > 207.0) & (a < 1.15)).astype(float) * 18.0
    fitness -= ((v > 84.0) & (c < 13.0)).astype(float) * 14.0

    return {
        "fitness": fitness,
        "quality": quality,
        "defects": defects,
        "throughput": throughput,
        "good_output": good_output,
        "energy": energy,
        "profit": profit,
    }


def tournament(population, fitness, rng, size, count):
    result = np.empty((count, population.shape[1]))
    for i in range(count):
        candidates = rng.integers(0, len(population), size=size)
        result[i] = population[candidates[np.argmax(fitness[candidates])]]
    return result


def crossover(a, b, rng, probability):
    if rng.random() > probability:
        return a.copy(), b.copy()
    alpha = rng.uniform(-0.20, 1.20, size=a.shape)
    child_a = alpha * a + (1.0 - alpha) * b
    child_b = alpha * b + (1.0 - alpha) * a
    return (
        np.clip(child_a, BOUNDS[:, 0], BOUNDS[:, 1]),
        np.clip(child_b, BOUNDS[:, 0], BOUNDS[:, 1]),
    )


def mutate(individual, rng, probability, strength):
    child = individual.copy()
    mask = rng.random(len(child)) < probability
    noise = rng.normal(0.0, strength, len(child)) * RANGES
    child[mask] += noise[mask]
    return np.clip(child, BOUNDS[:, 0], BOUNDS[:, 1])


def run_ga(
    population_size: int,
    generations: int,
    tournament_size: int,
    crossover_rate: float,
    mutation_rate: float,
    mutation_strength: float,
    elite_size: int,
    seed: int,
    callback: Callable | None = None,
):
    rng = np.random.default_rng(seed)
    population = rng.uniform(BOUNDS[:, 0], BOUNDS[:, 1], size=(population_size, 5))
    history = []

    for generation in range(generations):
        metrics = evaluate(population)
        fitness = metrics["fitness"]
        order = np.argsort(fitness)[::-1]
        elites = population[order[:elite_size]].copy()

        history.append({
            "Generacja": generation + 1,
            "Najlepszy fitness": float(fitness[order[0]]),
            "Średni fitness": float(np.mean(fitness)),
            "Różnorodność": float(np.mean(np.std(population / RANGES, axis=0))),
        })

        children_needed = population_size - elite_size
        parent_count = children_needed if children_needed % 2 == 0 else children_needed + 1
        parents = tournament(population, fitness, rng, tournament_size, parent_count)
        children = []

        for i in range(0, len(parents), 2):
            ca, cb = crossover(parents[i], parents[i + 1], rng, crossover_rate)
            children.append(mutate(ca, rng, mutation_rate, mutation_strength))
            children.append(mutate(cb, rng, mutation_rate, mutation_strength))

        population = np.vstack([elites, np.array(children[:children_needed])])

        if callback:
            callback(generation + 1, pd.DataFrame(history))

    final = evaluate(population)
    order = np.argsort(final["fitness"])[::-1]
    population = population[order]
    final = {key: value[order] for key, value in final.items()}
    return population, final, pd.DataFrame(history)


def style_figure(fig, height=420):
    fig.update_layout(
        height=height,
        margin=dict(l=25, r=25, t=55, b=25),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(15,23,42,.45)",
        font=dict(color="#dbeafe"),
        legend=dict(orientation="h", y=1.04, x=1, xanchor="right"),
    )
    fig.update_xaxes(gridcolor="rgba(148,163,184,.13)", zeroline=False)
    fig.update_yaxes(gridcolor="rgba(148,163,184,.13)", zeroline=False)
    return fig


def convergence(history):
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=history["Generacja"], y=history["Najlepszy fitness"],
        name="Najlepszy", mode="lines", line=dict(color="#67e8f9", width=3),
        fill="tozeroy", fillcolor="rgba(103,232,249,.08)"
    ))
    fig.add_trace(go.Scatter(
        x=history["Generacja"], y=history["Średni fitness"],
        name="Średni", mode="lines", line=dict(color="#c4b5fd", width=2)
    ))
    fig.update_layout(title="Ewolucja jakości populacji")
    fig.update_xaxes(title="Generacja")
    fig.update_yaxes(title="Fitness")
    return style_figure(fig, 390)


def radar(best):
    normalized = (best - BOUNDS[:, 0]) / RANGES * 100
    labels = [p.short for p in PARAMETERS]
    fig = go.Figure(go.Scatterpolar(
        r=np.r_[normalized, normalized[0]], theta=labels + [labels[0]],
        fill="toself", line=dict(color="#67e8f9", width=3),
        fillcolor="rgba(103,232,249,.16)"
    ))
    fig.update_layout(
        title="DNA najlepszej receptury",
        showlegend=False,
        polar=dict(
            bgcolor="rgba(15,23,42,.35)",
            radialaxis=dict(range=[0,100], gridcolor="rgba(148,163,184,.18)"),
            angularaxis=dict(gridcolor="rgba(148,163,184,.18)"),
        ),
    )
    return style_figure(fig, 440)


def parallel_plot(population, metrics, top_n=60):
    n = min(top_n, len(population))
    df = pd.DataFrame(population[:n], columns=[p.short for p in PARAMETERS])
    df["Jakość"] = metrics["quality"][:n]
    df["Braki"] = metrics["defects"][:n]
    df["Fitness"] = metrics["fitness"][:n]
    fig = px.parallel_coordinates(
        df,
        dimensions=[p.short for p in PARAMETERS] + ["Jakość", "Braki"],
        color="Fitness",
        color_continuous_scale="Turbo",
        title=f"Najlepsze {n} receptur na równoległych osiach",
    )
    return style_figure(fig, 500)


def landscape(best):
    temperatures = np.linspace(BOUNDS[0,0], BOUNDS[0,1], 54)
    speeds = np.linspace(BOUNDS[2,0], BOUNDS[2,1], 54)
    tg, vg = np.meshgrid(temperatures, speeds)
    candidates = np.tile(best, (tg.size, 1))
    candidates[:,0] = tg.ravel()
    candidates[:,2] = vg.ravel()
    z = evaluate(candidates)["fitness"].reshape(tg.shape)
    best_fitness = evaluate(best.reshape(1,-1))["fitness"][0]

    fig = go.Figure([
        go.Surface(x=tg, y=vg, z=z, colorscale="Turbo", opacity=.93),
        go.Scatter3d(
            x=[best[0]], y=[best[2]], z=[best_fitness],
            mode="markers+text", text=["ZWYCIĘZCA"], textposition="top center",
            marker=dict(size=8, color="white", symbol="diamond")
        )
    ])
    fig.update_layout(
        title="Krajobraz fitness: temperatura × prędkość",
        scene=dict(
            xaxis_title="Temperatura [°C]",
            yaxis_title="Prędkość [m/min]",
            zaxis_title="Fitness",
            bgcolor="rgba(15,23,42,.40)",
        ),
        showlegend=False,
    )
    return style_figure(fig, 620)


def scalar_metrics(metrics, index=0):
    return {key: float(value[index]) for key, value in metrics.items()}


st.markdown(
    """
    <div class="hero">
      <h1>GENESIS-5</h1>
      <p>Ewolucyjny optymalizator pięciu parametrów linii produkcyjnej.</p>
    </div>
    """,
    unsafe_allow_html=True,
)
st.caption(
    "Projekt szkoleniowy. Model procesu i ekonomii jest syntetyczny, "
    "lecz zawiera realistyczne kompromisy i ograniczenia technologiczne."
)

with st.sidebar:
    st.header("🧬 Parametry ewolucji")
    population_size = st.slider("Wielkość populacji", 40, 400, 160, 20)
    generations = st.slider("Liczba generacji", 20, 300, 120, 10)
    tournament_size = st.slider("Rozmiar turnieju", 2, 10, 4)
    crossover_rate = st.slider("Krzyżowanie", 0.0, 1.0, 0.88, 0.01)
    mutation_rate = st.slider("Mutacja genu", 0.0, 0.8, 0.14, 0.01)
    mutation_strength = st.slider("Siła mutacji", 0.005, 0.25, 0.055, 0.005)
    elite_size = st.slider("Liczba elit", 1, min(20, population_size // 4), 5)
    seed = st.number_input("Ziarno losowości", 0, 999999, 42)
    live_mode = st.toggle("Animuj przebieg", True)

    st.markdown("---")
    st.markdown("**Chromosom:** temperatura, ciśnienie, prędkość, chłodzenie, dodatek")

main_tab, manual_tab, theory_tab = st.tabs([
    "⚡ Ewolucja receptury", "🎛️ Symulator ręczny", "🧠 Mechanika algorytmu"
])

with main_tab:
    c1, c2 = st.columns([1.15, .85])
    with c1:
        st.subheader("Zadanie optymalizacyjne")
        st.write(
            "Znajdź ustawienia maksymalizujące jakość, produkcję dobrych wyrobów "
            "i wynik ekonomiczny, jednocześnie ograniczając braki oraz zużycie energii."
        )
    with c2:
        st.info(
            "Fitness jest wielokryterialny. Najszybsza linia nie musi być najlepsza, "
            "a najwyższa jakość może kosztować zbyt dużo energii i czasu."
        )

    run = st.button("URUCHOM EWOLUCJĘ", type="primary", use_container_width=True)

    if run:
        bar = st.progress(0, text="Tworzenie pierwszej populacji…")
        live_chart = st.empty()
        live_text = st.empty()
        every = max(1, generations // 22)

        def callback(generation, partial):
            bar.progress(generation / generations, text=f"Generacja {generation}/{generations}")
            if live_mode and (generation == 1 or generation % every == 0 or generation == generations):
                live_chart.plotly_chart(convergence(partial), use_container_width=True, key=f"live{generation}")
                live_text.info(
                    f"Fitness lidera: **{partial['Najlepszy fitness'].iloc[-1]:.2f}** | "
                    f"różnorodność: **{partial['Różnorodność'].iloc[-1]:.3f}**"
                )
                time.sleep(.02)

        population, metrics, history = run_ga(
            population_size, generations, tournament_size, crossover_rate,
            mutation_rate, mutation_strength, elite_size, int(seed), callback
        )
        st.session_state.population = population
        st.session_state.metrics = metrics
        st.session_state.history = history
        bar.progress(1.0, text="Ewolucja zakończona")
        live_chart.empty()
        live_text.empty()
        st.success("Znaleziono zwycięską recepturę produkcyjną.")
        st.balloons()

    if "population" in st.session_state:
        population = st.session_state.population
        metrics = st.session_state.metrics
        history = st.session_state.history
        best = population[0]
        result = scalar_metrics(metrics)

        st.markdown("## Receptura zwycięska")
        cols = st.columns(5)
        for col, parameter, value in zip(cols, PARAMETERS, best):
            with col:
                st.markdown(
                    f"""
                    <div class="card">
                      <div class="label">{parameter.name}</div>
                      <div class="value">{value:.{parameter.decimals}f}</div>
                      <div class="unit">{parameter.unit}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

        st.markdown("### Rezultat procesu")
        kpis = st.columns(6)
        kpis[0].metric("Fitness", f"{result['fitness']:.2f}")
        kpis[1].metric("Jakość", f"{result['quality']:.2f}%")
        kpis[2].metric("Braki", f"{result['defects']:.2f}%")
        kpis[3].metric("Produkcja brutto", f"{result['throughput']:.0f} kg/h")
        kpis[4].metric("Dobra produkcja", f"{result['good_output']:.0f} kg/h")
        kpis[5].metric("Energia", f"{result['energy']:.1f} kWh/h")
        st.metric("Szacowany wynik operacyjny", f"{result['profit']:.0f} PLN/h")

        a, b = st.columns([.8, 1.2])
        with a:
            st.plotly_chart(radar(best), use_container_width=True)
        with b:
            st.plotly_chart(convergence(history), use_container_width=True, key="final_convergence")

        st.plotly_chart(parallel_plot(population, metrics), use_container_width=True)
        st.plotly_chart(landscape(best), use_container_width=True)

        top = pd.DataFrame(population[:25], columns=[f"{p.short} [{p.unit}]" for p in PARAMETERS])
        top.insert(0, "Miejsce", np.arange(1, len(top)+1))
        top["Fitness"] = metrics["fitness"][:25]
        top["Jakość [%]"] = metrics["quality"][:25]
        top["Braki [%]"] = metrics["defects"][:25]
        top["Dobra produkcja [kg/h]"] = metrics["good_output"][:25]
        top["Energia [kWh/h]"] = metrics["energy"][:25]
        top["Wynik [PLN/h]"] = metrics["profit"][:25]

        with st.expander("25 najlepszych osobników"):
            st.dataframe(top.style.format(precision=2), use_container_width=True, hide_index=True)
            st.download_button(
                "Pobierz wyniki CSV",
                top.to_csv(index=False).encode("utf-8-sig"),
                "genesis5_top25.csv",
                "text/csv",
                use_container_width=True,
            )
    else:
        st.info("Ustaw parametry w panelu bocznym i uruchom algorytm.")

with manual_tab:
    st.subheader("Czy człowiek pokona ewolucję?")
    defaults = [188.0, 8.2, 65.0, 20.0, 2.2]
    values = []
    cols = st.columns(5)
    for col, parameter, default in zip(cols, PARAMETERS, defaults):
        with col:
            values.append(st.slider(
                parameter.name,
                float(parameter.low), float(parameter.high), float(default),
                step=10 ** (-parameter.decimals),
                format=f"%.{parameter.decimals}f",
                key=f"manual_{parameter.short}",
            ))
            st.caption(parameter.unit)

    manual = scalar_metrics(evaluate(np.array(values).reshape(1,-1)))
    kpis = st.columns(6)
    kpis[0].metric("Fitness", f"{manual['fitness']:.2f}")
    kpis[1].metric("Jakość", f"{manual['quality']:.2f}%")
    kpis[2].metric("Braki", f"{manual['defects']:.2f}%")
    kpis[3].metric("Dobra produkcja", f"{manual['good_output']:.0f} kg/h")
    kpis[4].metric("Energia", f"{manual['energy']:.1f} kWh/h")
    kpis[5].metric("Wynik", f"{manual['profit']:.0f} PLN/h")

    if "metrics" in st.session_state:
        winner = scalar_metrics(st.session_state.metrics)
        delta = winner["fitness"] - manual["fitness"]
        if delta > 0:
            st.warning(f"Receptura GA prowadzi o **{delta:.2f} punktu fitness**.")
        else:
            st.success(f"Ustawienie ręczne prowadzi o **{-delta:.2f} punktu**. Zwiększ budżet GA!")

with theory_tab:
    st.subheader("Chromosom")
    st.code(
        "osobnik = [temperatura, ciśnienie, prędkość, chłodzenie, dodatek]",
        language="python",
    )
    st.markdown(
        """
        ### Pętla ewolucyjna
        1. Losujemy populację receptur.
        2. Symulujemy jakość, braki, wydajność, energię i wynik ekonomiczny.
        3. Selekcja turniejowa wybiera rodziców.
        4. Krzyżowanie BLX miesza ich parametry.
        5. Mutacja gaussowska otwiera nowe obszary poszukiwań.
        6. Elita przechodzi bez zmian do kolejnej generacji.
        """
    )
    st.latex(r"fitness=0.43Q+0.25T+0.13(100-E)+0.11(100-D)+0.08P-kary")
    st.warning(
        "W prawdziwym projekcie model oceny powinien pochodzić z danych historycznych, "
        "modelu predykcyjnego, cyfrowego bliźniaka albo pomiarów procesu."
    )
